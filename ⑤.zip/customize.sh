#!/system/bin/sh
MODDIR=${0%/*}

ui_print "======================================="
ui_print "Selinux漏洞修复模块安装"
ui_print "======================================="
ui_print "- 版本: 无需更新"
ui_print "- 作者: 有始有终"
ui_print "======================================="

# 设置文件权限
set_perm_recursive $MODDIR 0 0 0755 0777
set_perm_recursive $MODDIR/common 0 0 0755 0777

# 设置脚本执行权限

ui_print "- 模块安装完成"
    

ui_print "- 安装后无需手动配置，本模块针对于部分挂（不点名某3K内部）导致的频繁封号问题有奇效。"