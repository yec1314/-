#!/system/bin/sh
MODDIR=${0%/*}

ui_print "======================================="
ui_print "无后台自动改persist权限"
ui_print "======================================="
ui_print "- 版本: 1.0"
ui_print "- 模块作者: 月初"
ui_print "======================================="

# 设置文件权限
set_perm_recursive $MODDIR 0 0 0755 0644
set_perm_recursive $MODDIR/common 0 0 0755 0755
# 设置脚本执行权限
set_perm $MODDIR/common/service.sh 0 0 0755

ui_print "模块安装完成"

