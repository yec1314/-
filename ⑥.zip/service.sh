#之前网传的解决设备标记模块，用MT新建脚本执行即可。重启失效

#实测可以解决轻度设备标记

#!/system/bin/sh
MODDIR=${0%/*}
GAME_PKG="com.tencent.mf.uam"  # 暗区包名
# 定义启动和结束时执行的脚本路径（可根据实际情况修改）
START_SCRIPT="$MODDIR/common/service.sh"  # 游戏启动时执行的脚本
STOP_SCRIPT="$MODDIR/common/恢复权限.sh"    # 游戏结束时执行的脚本

# 标记是否已执行过启动脚本（避免重复执行）
has_started=0

ui_print "开始监控暗区进程..."

while true; do
    # 检测游戏进程是否存在
    if pgrep -f "$GAME_PKG" >/dev/null; then
        # 进程存在且未执行过启动脚本时，执行启动脚本
        if [ $has_started -eq 0 ]; then
            ui_print "检测到暗区已启动，执行启动脚本..."
            if [ -f "$START_SCRIPT" ]; then
                sh "$START_SCRIPT"
                echo "[Monitor] 暗区启动，已执行启动脚本" >> /data/adb/persist_guard.log
            else
                echo "[Monitor] 启动脚本不存在：$START_SCRIPT" >> /data/adb/persist_guard.log
            fi
            has_started=1  # 标记为已执行启动脚本
        fi
    else
        # 进程不存在但已执行过启动脚本时，执行结束脚本
        if [ $has_started -eq 1 ]; then
            ui_print "检测到暗区已结束，执行结束脚本..."
            if [ -f "$STOP_SCRIPT" ]; then
                sh "$STOP_SCRIPT"
                echo "[Monitor] 暗区结束，已执行结束脚本" >> /data/adb/persist_guard.log
            else
                echo "[Monitor] 结束脚本不存在：$STOP_SCRIPT" >> /data/adb/persist_guard.log
            fi
            has_started=0  # 重置标记，等待下次启动
        fi
    fi
    sleep 2  # 每隔2秒检测一次
done